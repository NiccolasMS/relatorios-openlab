/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class BolsaFilhos {
    public static void main(String[] args) {
        Scanner scanInteger = new Scanner(System.in);
        
        Double primeiroSaldo = 25.12;
        Double segundoSaldo = 15.88;
        Double terceiroSaldo = 12.44;
        
        System.out.println("Quantos filhos de 0 a 3 anos você possui?");
        Integer primeiraQuantidade = scanInteger.nextInt();
        
        Double primeiroResultado = primeiraQuantidade * primeiroSaldo;
        
        System.out.println("Quantos filhos de 4 a 16 anos você possui?");
        Integer segundaQuantidade = scanInteger.nextInt();
        
        Double segundoResultado = segundaQuantidade * segundoSaldo;
        
        System.out.println("Quantos filhos de 17 a 18 anos você possui?");
        Integer terceiraQuantidade = scanInteger.nextInt();
        
        Double terceiroResultado =  terceiraQuantidade * terceiroSaldo;
        
        Double totalBolsa = primeiroResultado + segundoResultado + 
                terceiroResultado;
        
        Integer totalFilhos = primeiraQuantidade + segundaQuantidade +
                terceiraQuantidade;
        
        System.out.println(String.format("Você tem um total de %d filhos e vai"
                + " receber R$%.2f de bolsa", totalFilhos, totalBolsa));
        
        
    }
}
