/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class Idade {
    public static void main(String[] args) {
        Scanner scanString = new Scanner(System.in);
        Scanner scanInteger = new Scanner(System.in);
        
        System.out.println("Digite seu nome: ");
        String nome = scanString.nextLine();
        
        System.out.println(String.format("Olá, %s! Qual o ano de seu "
                + "nascimento?", nome));
        Integer anoNascimento = scanInteger.nextInt();
        
        Integer idade = 2030 - anoNascimento;
        
        System.out.println(String.format("Em 2030 você terá %d anos", idade));
    }
    
}
