/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class PerderCalorias {
    public static void main(String[] args) {
        Scanner scanInteger = new Scanner(System.in);
        
        Integer minutoAquecimento = 12;
        Integer minutoAerobico = 20;
        Integer minutoMusculacao = 25;
        
        System.out.println("Quanto tempo, em minutos você passou se "
                + "aquecendo?");
        Integer tempoAquecendo = scanInteger.nextInt();
        
        Integer caloriaAquecimento = minutoAquecimento * tempoAquecendo;
        
        System.out.println("Quanto tempo, em minutos você passou fazendo "
                + "exercícios aeróbicos?");
        Integer tempoFazendoAerobicos = scanInteger.nextInt();
        
        Integer caloriaAerobico = minutoAerobico * tempoFazendoAerobicos;
        
        System.out.println("Quanto tempo, em minutos você passou fazendo "
                + "exercícios de musculação?");
        Integer tempoFazendoMusculacao = scanInteger.nextInt();
        
        Integer caloriaMusculacao = minutoMusculacao * tempoFazendoMusculacao;
        
        Integer totalMinutos = tempoAquecendo + tempoFazendoAerobicos + 
                tempoFazendoMusculacao;
        
        Integer totalCalorias = caloriaAquecimento + caloriaAerobico +
                caloriaMusculacao;
        
        System.out.println(String.format("Você fez um total de %d minutos de "
                + "exercícios e perdeu cerca de %d calorias.", totalMinutos, 
                totalCalorias));
        
    }
}
