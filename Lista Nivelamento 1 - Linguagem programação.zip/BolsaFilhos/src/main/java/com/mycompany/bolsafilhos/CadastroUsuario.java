/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class CadastroUsuario {
    public static void main(String[] args) {
        Scanner scanString = new Scanner(System.in);
        Scanner scanInteger = new Scanner(System.in);
        
        System.out.println("Digite seu login: ");
        String loginCliente = scanString.nextLine();
        
        System.out.println("Digite sua senha: ");
        String senhaCliente = scanString.nextLine();
        
        System.out.println("Digite a quantidade de vezes que você aceita errar"
                + "sua senha antes do bloqueio: ");
        Integer quantidadeVezes = scanInteger.nextInt();
        
        System.out.println(String.format("Seu login é %s e sua senha é %s.\n"
                + "Você tem %d tentativas antes de ser bloqueado.", loginCliente, senhaCliente, quantidadeVezes));
    }
}
