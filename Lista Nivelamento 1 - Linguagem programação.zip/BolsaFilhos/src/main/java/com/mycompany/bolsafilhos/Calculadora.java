/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class Calculadora {
    public static void main(String[] args) {
        Scanner scanDouble = new Scanner(System.in);
        
        System.out.println("Digite um número: ");
        Double numero1 = scanDouble.nextDouble();
        
        System.out.println("Digite outro número: ");
        Double numero2 = scanDouble.nextDouble();
        
        Double soma = numero1 + numero2;
        Double subtracao = numero1 - numero2;
        Double multiplicacao = numero1 * numero2;
        Double divisao = numero1 / numero2;
        
        System.out.println("Resultado da soma:\n" + soma);
        System.out.println("Resultado da subtração:\n" + subtracao);
        System.out.println("Resultado da multiplicação:\n" + multiplicacao);
        System.out.println("Resultado da divisão:\n" + divisao);
    }
}
