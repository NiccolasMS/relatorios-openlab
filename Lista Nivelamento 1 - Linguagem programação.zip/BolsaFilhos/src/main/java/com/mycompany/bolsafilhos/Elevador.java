/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class Elevador {
    public static void main(String[] args) {
        Scanner scanDouble = new Scanner(System.in);
        Scanner scanInteger = new Scanner(System.in);
        
        System.out.println("Limite o peso do elevador: ");
        Double pesoElevador = scanDouble.nextDouble();
        
        System.out.println("Limite de pessoas dentro do elevador: ");
        Integer limitePessoas = scanInteger.nextInt();
        
        System.out.println("Digite o peso da 1ª pessoa: ");
        Double primeiraPessoa = scanDouble.nextDouble();
        
        System.out.println("Digite o peso da 2ª pessoa: ");
        Double segundaPessoa = scanDouble.nextDouble();        
        
        System.out.println("Digite o peso da 3ª pessoa: ");
        Double terceiraPessoa = scanDouble.nextDouble();
        
        Double totalPeso = primeiraPessoa + segundaPessoa + terceiraPessoa;
        
        System.out.println(String.format("Entraram 3 pessoas no elevador, no "
                + "qual cabem %d pessoas.\n O peso total no elevador é de %.2f,"
                + " sendo que ele suporta %.2f", limitePessoas, totalPeso, 
                pesoElevador));
    }
    
}
