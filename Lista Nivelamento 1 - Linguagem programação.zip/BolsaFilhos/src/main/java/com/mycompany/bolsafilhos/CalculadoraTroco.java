/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class CalculadoraTroco {
    public static void main(String[] args) {
        Scanner scanDouble = new Scanner(System.in);
        
        System.out.println("Digite o valor unitario de um produto: ");
        Double valorProduto = scanDouble.nextDouble();
        
        System.out.println("Digite a quantidade do produto: ");
        Integer quantidadeProduto = scanDouble.nextInt();
        
        System.out.println("Digite o valor a ser pago: ");
        Double valorPagar = scanDouble.nextDouble();
        
        
        Double totalPagar = valorProduto * quantidadeProduto;
        Double troco = valorPagar - totalPagar;
        
        System.out.println(String.format("Seu troco será de R$%.2f", troco));
        
    }
    
}
