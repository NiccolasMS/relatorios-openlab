/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class CalculoMedia {
    public static void main(String[] args) {
        Scanner scanDouble = new Scanner(System.in);
        Scanner scanString = new Scanner(System.in);
        
        System.out.println("Digite seu nome: ");
        String nome = scanString.nextLine();
        
        System.out.println("Digite sua primeira nota: ");
        Double primeiraNota = scanDouble.nextDouble();
        
        System.out.println("Digite sua segunda nota: ");
        Double segundaNota = scanDouble.nextDouble();
        
        Double media = (primeiraNota + segundaNota)/2;
        
        System.out.println(String.format("Olá, %s. Sua média foi de %.1f",
                nome, media));
    }
}
