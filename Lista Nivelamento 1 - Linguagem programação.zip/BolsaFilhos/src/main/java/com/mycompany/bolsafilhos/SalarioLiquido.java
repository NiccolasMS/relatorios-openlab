/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bolsafilhos;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class SalarioLiquido {
    public static void main(String[] args) {
        Scanner scanDouble = new Scanner(System.in);
        
        System.out.println("Digite seu salário bruto: ");
        Double salarioBruto = scanDouble.nextDouble();
        
        Double INSS = (0.1*salarioBruto)/100;
        Double IR = (0.2*salarioBruto)/100;
        
        System.out.println("Quanto custa a condução diária só de ida para o "
                + "trabalho?");
        Double VT = scanDouble.nextDouble();
        
        VT = (VT*2)*22;
        
        Double totalDescontos = INSS + IR + VT;
        
        Double salarioLiquido = salarioBruto - totalDescontos;
        
        System.out.println(String.format("Seu salário bruto é R$%.2f, tem um"
                + " total de R$%.2f em descontos e receberá um líquido de "
                + "R$%.2f", salarioBruto, totalDescontos, salarioLiquido));
        
    }
    
}
