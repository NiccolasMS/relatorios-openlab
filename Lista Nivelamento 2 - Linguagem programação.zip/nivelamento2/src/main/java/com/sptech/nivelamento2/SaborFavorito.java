/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sptech.nivelamento2;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class SaborFavorito {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Integer votoMussarela = 0;
        Integer votoCalabresa = 0;
        Integer votoQuatroQueijos = 0;

        for (int i = 1; i <= 10; i++) {
            System.out.println(String.format("%dº Aluno,vote em uma pizza!\n ", i));
            System.out.println("Para Mussarela, digite: 5");
            System.out.println("Para Calabresa, digite: 25");
            System.out.println("Para Quatro Queijos, digite: 50\n");
            Integer numeroVotado = scan.nextInt();
            if (numeroVotado.equals(5)) {
                votoMussarela++;
            } else if (numeroVotado.equals(25)) {
                votoCalabresa++;
            } else if (numeroVotado.equals(50)) {
                votoQuatroQueijos++;
            }

        }
        System.out.println(String.format("Mussarela: %d votos\n"
                + "Calabresa: %d votos\n Quatro Queijos: %d votos\n",
                votoMussarela, votoCalabresa, votoQuatroQueijos));
        if (votoMussarela > votoCalabresa && votoMussarela > votoQuatroQueijos) {
            System.out.println("Mussarela é o sabor favorito!!");
        } else if (votoCalabresa > votoMussarela && votoCalabresa > votoQuatroQueijos) {
            System.out.println("Calabresa é o sabor favorito!!");
        } else if (votoQuatroQueijos > votoMussarela && votoQuatroQueijos > votoCalabresa) {
            System.out.println("Quatro Queijos é o sabor favorito!!");
        }
    }
}
