/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sptech.nivelamento2;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Nicolas
 */
public class Sorteio {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Digite um numero de 1 a 100: ");
        Integer numeroDigitado = scan.nextInt();
        
        Integer numeroRandom = ThreadLocalRandom.current().nextInt(1, 101);
        
        Integer numeroPar = 0;
        Integer numeroImpar = 0;
        for (int i = 0; i < 201; i++) {
            numeroRandom = ThreadLocalRandom.current().nextInt(1, 101);
            System.out.println(String.format("%dº Numero sorteado: %d", i, 
                    numeroRandom));
            if(numeroDigitado.equals(numeroRandom)){
                System.out.println(String.format("Parábens, seu numero "
                        + "foi sorteado depois de %d vezes\n", i));
                System.out.println(String.format("Foram sorteados %d numeros"
                        + " pares", numeroPar));
                System.out.println(String.format("Foram sorteados %d numeros"
                        + " impares", numeroImpar));
                break;
            }
            else if (numeroRandom % 2 == 0) {
                numeroPar++;
            }
            else if (numeroRandom % 2 == 1) {
                numeroImpar++;
            }
        }
    }
}
