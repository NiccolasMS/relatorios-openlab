/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sptech.nivelamento2;

/**
 *
 * @author Nicolas
 */
public class ContadorVariado {
    public static void main(String[] args) {
        Double numeroVariado = 0.15;
        Double resultado = 0.00;
        for (double i = 0; resultado < 4.95; i++) {
            resultado += numeroVariado;
            System.out.println(String.format("%.2f", resultado));
        }
    }
}
